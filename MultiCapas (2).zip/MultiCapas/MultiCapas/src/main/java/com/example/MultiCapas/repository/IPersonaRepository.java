package com.example.MultiCapas.repository;

import com.example.MultiCapas.model.Persona;

public interface IPersonaRepository {
    public void guardarPersona(Persona per);
    public void eliminarPersona(Persona per);
    public void actualizarPersona(Persona per);
    public void obtenerPersona(Persona per);



}

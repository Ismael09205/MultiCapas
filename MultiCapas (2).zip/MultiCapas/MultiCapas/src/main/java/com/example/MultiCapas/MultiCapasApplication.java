package com.example.MultiCapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiCapasApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiCapasApplication.class, args);
	}

}

package com.example.MultiCapas.service;

import com.example.MultiCapas.model.Persona;
import com.example.MultiCapas.repository.IPersonaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaService implements IPersonaService{
    //Inyeccion de dependencias
    private final IPersonaRepository repo;
    private PersonaService(IPersonaRepository repo){
        this.repo=repo;
    }
    /// //////////////////////////
    @Override
    public void crearPersona(Persona per) {
        System.out.println("Persona Creada");
        repo.guardarPersona(per);
    }

    @Override
    public List<Persona> traerPersonas() {
        return List.of();
    }
}

package com.example.MultiCapas.model;

public class Persona {
}

package com.example.MultiCapas.service;

import com.example.MultiCapas.model.Persona;

import java.util.List;

public interface IPersonaService {
    public void crearPersona(Persona per);
    public List<Persona> traerPersonas();
}

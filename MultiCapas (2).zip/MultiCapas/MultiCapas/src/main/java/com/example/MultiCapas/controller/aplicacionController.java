package com.example.MultiCapas.controller;

import com.example.MultiCapas.service.IPersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class aplicacionController{

    private final IPersonaService service;
    public aplicacionController(IPersonaService service){
        this.service=service;
    }
    //Inyeccion de dependencias
    //IPERSONASERVICE POR QUE EL ORDEN ES
    // CONTROLADOR LLAMA A SERVICIO Y SERVICIO LLAMA A REPOSITORIO
}

package com.example.MultiCapas.repository;

import com.example.MultiCapas.model.Persona;
import com.example.MultiCapas.service.IPersonaService;

public class PersonaRepository implements IPersonaRepository{

    @Override
    public void guardarPersona(Persona per) {
        //LOGICA PARA ESTE
    }

    @Override
    public void eliminarPersona(Persona per) {

    }

    @Override
    public void actualizarPersona(Persona per) {

    }

    @Override
    public void obtenerPersona(Persona per) {

    }
}

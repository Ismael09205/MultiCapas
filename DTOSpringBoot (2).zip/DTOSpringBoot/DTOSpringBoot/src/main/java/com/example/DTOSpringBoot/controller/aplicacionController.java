package com.example.DTOSpringBoot.controller;

import com.example.DTOSpringBoot.dto.PropiedadDTO;
import com.example.DTOSpringBoot.model.Inquilino;
import com.example.DTOSpringBoot.model.Propiedad;
import org.springframework.web.bind.annotation.*;

@RestController
public class aplicacionController {
    @GetMapping("/propiedad/{id}")
    @ResponseBody
    public PropiedadDTO devolverPropiedad(@PathVariable Long id) {
        Propiedad prop = new Propiedad(1548L, "Casa", "Avenida Siempre viva", 120.5, 25000.0);
        Inquilino inqui = new Inquilino(1L, "33445566", "Alonso", "Guzman", "Operario de Maquinas");

        PropiedadDTO propInquiDTO = new PropiedadDTO();
        propInquiDTO.setId_propiedad(prop.getId_propiedad());
        propInquiDTO.setTipo_propiedad(prop.getTipo_propiedad());
        propInquiDTO.setDireccion(prop.getDireccion());
        propInquiDTO.setValor_alquiler(prop.getValor_alquiler());
        propInquiDTO.setNombre(inqui.getNombre());
        propInquiDTO.setApellido(inqui.getApellido());

        return propInquiDTO;
    }
@GetMapping("/requestID")
    public PropiedadDTO requestParamExample(@RequestParam String id) {
    Propiedad prop = new Propiedad(1548L, "Casa", "Avenida Siempre viva", 120.5, 25000.0);
    Inquilino inqui = new Inquilino(1L, "33445566", "Alonso", "Guzman", "Operario de Maquinas");

    PropiedadDTO propInquiDTO2 = new PropiedadDTO();

    propInquiDTO2.setId_propiedad(prop.getId_propiedad());
    propInquiDTO2.setTipo_propiedad(prop.getTipo_propiedad());
    propInquiDTO2.setDireccion(prop.getDireccion());
    propInquiDTO2.setValor_alquiler(prop.getValor_alquiler());
    propInquiDTO2.setNombre(inqui.getNombre());
    propInquiDTO2.setApellido(inqui.getApellido());

    return propInquiDTO2;
    }

}

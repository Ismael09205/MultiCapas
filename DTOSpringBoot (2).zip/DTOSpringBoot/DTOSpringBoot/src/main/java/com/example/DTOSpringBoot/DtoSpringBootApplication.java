package com.example.DTOSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtoSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtoSpringBootApplication.class, args);
	}

}

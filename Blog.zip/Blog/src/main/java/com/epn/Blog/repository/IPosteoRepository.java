package com.epn.Blog.repository;

import com.epn.Blog.model.Posteo;

import java.util.List;

public interface IPosteoRepository {
    // Mandar a persisitir la base de datos eso hace un repository
    // Simulamos el metodo para traer todos los Posteos de la BD
    public List<Posteo> traerTodos();

}

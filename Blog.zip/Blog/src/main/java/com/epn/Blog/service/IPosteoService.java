package com.epn.Blog.service;

import java.util.List;
import com.epn.Blog.model.Posteo;
public interface IPosteoService {
    public List<Posteo> obtenerTodosLosPosteos();
    public List<Posteo> obtenerPosteosPorAutor(String autor);
}

package com.epn.Blog.service;

import com.epn.Blog.model.Posteo;
import com.epn.Blog.repository.IPosteoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PosteoService implements IPosteoService {

    private final IPosteoRepository repository;
    public PosteoService(IPosteoRepository repository) {
        this.repository = repository;
    }

    @Override
    public List<Posteo> obtenerTodosLosPosteos() {
        //Aqui agregamos la loguica del negocio validaciones,/***************************** OJOOOOOO****************
        //TENER EN CUENTA EL ORDEN EN EL QUE VAN LAS CAPAS DEL PROYECTO
        // transformaciones, cosas que necesita el negocio,
        // que forma parte de suss reglas requerimientos y son independientes de su tecnologia
        List<Posteo> listaPosteos = repository.traerTodos();
        return listaPosteos;
    }

    @Override
    public List<Posteo> obtenerPosteosPorAutor(String autor) {
        List<Posteo> listaFiltrada=repository.traerTodos();
        //Stream se conoce como Tuberia de datos, permite procesar una coleccion de datos sin bucles si no de forma declarativa
        //filter consertva solo los posteos cuyo autor coincida con el parametro autor, ignora minusculas y mayusculas
        return listaFiltrada.stream().filter(listaFiltrada -> listaFiltrada.getAutor().equalsIgnoreCase(autor)).toList();
    }
}

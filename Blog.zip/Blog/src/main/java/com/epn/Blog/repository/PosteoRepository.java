package com.epn.Blog.repository;

import com.epn.Blog.model.Posteo;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
@Repository
public class PosteoRepository implements IPosteoRepository {


    //Aqui simulamos la logica para la interaccion a la base de datos
    @Override
    public List<Posteo> traerTodos() {
        List<Posteo> listaPosteos =new ArrayList<>();
        //Simular que hay datos en la base de datos mismos que voy a recuperar
        listaPosteos.add(new Posteo(1L,"Como formatear una PC","Ismael Narvaez"));
        listaPosteos.add(new Posteo(1L,"Como crear un circuito","Juan Salas"));
        //-***************************************-
        return listaPosteos;
    }
}

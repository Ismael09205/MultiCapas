package com.epn.Blog.controller;

import com.epn.Blog.model.Posteo;
import com.epn.Blog.service.IPosteoService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class aplicacionController {
private final IPosteoService posteoService;
//El controlador va hacia el servicio Controller-Service-Repository
    public aplicacionController(IPosteoService posteoService) {
        this.posteoService = posteoService;
    }
    @GetMapping("/posteos")
    public List<Posteo> obtenerPosteos(){
        return posteoService.obtenerTodosLosPosteos();
    }
    @GetMapping ("/posteos/autor")
    public List<Posteo> traerPorAutor(@RequestParam String autor){
        return posteoService.obtenerPosteosPorAutor(autor);
    }
}

